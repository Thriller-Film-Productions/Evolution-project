module.exports = process.atomBinding('power_save_blocker').powerSaveBlocker
