module.exports = process.atomBinding('content_tracing')
