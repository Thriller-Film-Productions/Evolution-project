module.exports = process.atomBinding('global_shortcut').globalShortcut
