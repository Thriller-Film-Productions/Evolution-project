module.exports = process.atomBinding('shell')
