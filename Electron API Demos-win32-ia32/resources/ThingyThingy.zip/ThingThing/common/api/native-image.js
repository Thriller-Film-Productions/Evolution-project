module.exports = process.atomBinding('native_image')
