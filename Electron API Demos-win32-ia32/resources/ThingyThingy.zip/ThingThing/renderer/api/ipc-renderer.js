'use strict'

const binding = process.atomBinding('ipc')
const v8Util = process.atomBinding('v8_util')

// Created by init.js.
const ipcRenderer = v8Util.getHiddenValue(global, 'ipc')
require('./ipc-renderer-setup')(ipcRenderer, binding)

module.exports = ipcRenderer
