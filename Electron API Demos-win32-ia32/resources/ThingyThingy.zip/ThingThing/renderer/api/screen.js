module.exports = require('electron').remote.screen
